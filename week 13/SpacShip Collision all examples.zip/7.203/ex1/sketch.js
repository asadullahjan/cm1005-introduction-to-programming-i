

function setup()
{
    createCanvas(500,500);

    textSize(40);
    
}

function draw()
{
    background(0);
    noStroke();
    fill(255);

}


function sayHello()
{

}